import React, { Component } from "react";

class Contact extends Component {
  render() {
    return (
      <div>
        <h2>CONTACT INFO</h2>
        <p>Please email all questions to
        our <a href="mailto:support@chronic-data.io">support@chronic-data.io</a>.
        </p>
      </div>
    );
  }
}

export default Contact;
