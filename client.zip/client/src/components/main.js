import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div>
        <h2>WELCOME</h2>
        <p>To add documents select documents button from toolbar above.
        </p>
      </div>
    );
  }
}

export default Home;
