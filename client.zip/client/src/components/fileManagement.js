import React, { Component } from "react";

class FileManagement extends Component {
  render() {
    return (
      <div>
        <h2>File Management</h2>
        <p>view all documents.
        </p>
      </div>
    );
  }
}

export default FileManagement;
